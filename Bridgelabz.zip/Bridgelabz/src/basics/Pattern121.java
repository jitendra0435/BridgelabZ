package basics;

public class Pattern121 {

	public static void main(String[] args)
	{
		int i,j,temp=1;
		
		for(i=1;i<=4;i++)
		{
			
			for(j=1;j<=i;j++)
			{
				System.out.print(temp);
				temp++;
				
			}
			System.out.println(" ");
		}
	

	}

}
