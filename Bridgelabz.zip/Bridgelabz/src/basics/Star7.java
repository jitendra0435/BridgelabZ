package basics;

public class Star7 {

	public static void main(String[] args)
	{
		
		int i,j,k;
		
		
		
		
		

	}

}
