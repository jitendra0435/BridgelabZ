package basics;

public class Pattern12 {

	public static void main(String[] args)
	{
	
		 int i,j;
		 for(i=0;i<=4;i++)
		 {
			 for(j=0;j<i;j++)
			 {
				 System.out.print(j);
				 
			 }
			 System.out.println(" ");
			 
		 }

	}

}
