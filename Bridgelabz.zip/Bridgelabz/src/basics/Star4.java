package basics;

public class Star4 {

	public static void main(String[] args) {
		
		int i,j,k;
		
		for(i=1;i<=5;i++)
		{
			for(j=5;j>=i;j--)
			{
				System.out.print(" *");
			}
			
		System.out.print("\n");
		}

	}

}
