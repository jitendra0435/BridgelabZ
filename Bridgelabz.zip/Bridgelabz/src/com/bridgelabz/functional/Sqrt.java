package com.bridgelabz.functional;

public class Sqrt {
	
	
	
	void Sqrt1(double c)
	{
		System.out.println(Math.sqrt(c));
		
		
	}
	void Sqrt1(double a,double b)
	{
		System.out.println(Math.sqrt(a));
		System.out.println(Math.sqrt(b));
	}

	public static void main(String[] args)
	{
	   
		Sqrt t1=new Sqrt();
		t1. Sqrt1(10);
		t1.Sqrt1(10,20);
		

	}

}
