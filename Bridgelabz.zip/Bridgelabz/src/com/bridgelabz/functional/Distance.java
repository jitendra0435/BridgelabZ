package com.bridgelabz.functional;

import java.util.Scanner;

public class Distance 
{

	public static void main(String args[])
	{
		
		int x=Integer.parseInt("x");
		int y=Integer.parseInt("y");
		
		double Square=Math.sqrt(x+y);
	
		
		
		
	}
	
}
