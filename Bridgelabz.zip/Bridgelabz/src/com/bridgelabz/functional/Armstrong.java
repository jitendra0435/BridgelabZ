package com.bridgelabz.functional;

public class Armstrong {

	public static void main(String[] args)
	{
		int num=153;
		int temp=num;
		int rem,sum=0;
		
		while(num>0)
		{
			rem=num%10;
			sum=sum+(rem*rem*rem);
			num=num/10;
			
			
			
		}
		if(sum==temp)
		{
			System.out.println("\n Number is Armstrong");
		}
		else
			System.out.println("\n Not armstrong");

	}

}
