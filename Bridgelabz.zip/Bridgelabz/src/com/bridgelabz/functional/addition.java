package com.bridgelabz.functional;

import java.util.Scanner;

public class addition
{
    int a,b,c;
 void add()
 {
	 
	 System.out.println("\n enter number want to add");
	 Scanner sc=new Scanner(System.in);
	 a=sc.nextInt();
	 b=sc.nextInt();
	 c=a+b;
	 
 }
	
	
}
