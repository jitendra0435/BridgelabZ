package com.bridgelabz.utility;

public class utility
{
	public static void main(String args[])
	{
	utility u1=new utility();
	}
		
	

}
