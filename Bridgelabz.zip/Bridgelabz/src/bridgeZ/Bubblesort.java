package bridgeZ;

import java.util.Scanner;

public class Bubblesort 
{
   void BubbleSort()
   {
	   
	   int[]a=new int [10];
	   
	   Scanner sc=new Scanner(System.in);
	   System.out.println("\n Enter Array element=");
	   
	   for(int i=0;i<10;i++)
	   {
		   
		   a[i]=sc.nextInt();
		   
		   
		   
	   }
	   
	   
	   
	   
   }
	
	
	
	
	
	
	
	
	
	
	
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub

	}

}
